# """
# vision_toolkit.py — skrinshot olish va AI (vision LLM) orqali JSON
# qilish funksiyalari. Mustaqil sikli yo'q — capture_pipeline.py buni
# chaqiradi.
# """

# import base64
# import io
# import json
# import time

# import requests
# from PIL import Image

# from config import (
#     CAPTURE_MODE,
#     SCADA_URL,
#     SCADA_WINDOW_TITLE,
#     KNOWN_SENSOR_LABELS,
#     OLLAMA_BASE_URL,
#     VISION_MODEL,
#     MAX_RETRIES,
#     RETRY_DELAY_SECONDS,
#     IMAGE_MAX_WIDTH,
#     IMAGE_JPEG_QUALITY,
#     OLLAMA_TIMEOUT_SECONDS,
# )

# BASE_PROMPT = """Bu — sanoat SCADA/HMI tizimining ekran suratidir (skrinshot).
# Vazifang: rasmda ko'ringan BARCHA o'lchov qiymatlarini, barcha
# uskuna/aktuator holatlarini va barcha alarm/ogohlantirish xabarlarini
# quyidagi JSON formatida chiqarib ber:

# {
#   "readings": {"<ekranda ko'ringan nom>": <son yoki matn>, ...},
#   "equipment_states": {"<uskuna nomi>": "<ON/OFF/OPEN/CLOSED va h.k.>", ...},
#   "alarms": ["<ekranda ko'ringan har bir alarm matni>", ...],
#   "low_confidence_fields": ["<aniq emas deb hisoblagan kalitlar>", ...],
#   "screen_title": "<ekran sarlavhasi, agar ko'ringan bo'lsa>"
# }

# Muhim qoidalar:
# - Faqat rasmda HAQIQATDA ko'ringan narsalarni yoz, o'zingdan hech narsa qo'shma
# - Nomlarni ekranda yozilgan holicha qoldir, tarjima qilma
# - Bo'lim rasmda umuman bo'lmasa, mos maydonni bo'sh qoldir
# - Faqat JSON qaytar, boshqa hech qanday izoh yozma

# === ANALOG STRELKALI ASBOBLAR UCHUN QOIDA ===
# Raqamli yozuv bo'lsa — shunga tayan. Faqat strelka bo'lsa — taxmin qil
# va "low_confidence_fields"ga qo'sh.

# === 7-SEGMENT DISPLEYLAR UCHUN QOIDA ===
# Noaniq raqam bo'lsa — eng ehtimolli variantni yoz va
# "low_confidence_fields"ga qo'sh.

# === RANGLI INDIKATORLAR UCHUN QOIDA ===
# Chiroq holatini "equipment_states"da aniq so'z bilan ifodala (ON/OFF/
# RUNNING/STOPPED). Noaniq bo'lsa "UNKNOWN"."""


# def _build_prompt() -> str:
#     if not KNOWN_SENSOR_LABELS:
#         return BASE_PROMPT
#     mapping_lines = "\n".join(
#         f'- "{label}" ko\'rinsa -> kalit nomi sifatida "{key}" ishlat'
#         for label, key in KNOWN_SENSOR_LABELS.items()
#     )
#     return BASE_PROMPT + "\n\n=== MA'LUM KALIT NOMLARI ===\n" + mapping_lines


# PROMPT = _build_prompt()


# def take_screenshot_from_url(path: str = "shot.png"):
#     from playwright.sync_api import sync_playwright

#     with sync_playwright() as p:
#         browser = p.chromium.launch()
#         page = browser.new_page(viewport={"width": 1920, "height": 1080}, device_scale_factor=2)
#         page.goto(SCADA_URL, timeout=45000, wait_until="domcontentloaded")
#         try:
#             page.wait_for_load_state("networkidle", timeout=15000)
#         except Exception:
#             pass
#         page.wait_for_timeout(9000)
#         page.screenshot(path=path, full_page=True)
#         browser.close()
#     return path


# def take_screenshot_from_window(path: str = "shot.png"):
#     import win32gui
#     import win32ui
#     from ctypes import windll

#     hwnd_result = {"hwnd": None}

#     def _callback(hwnd, _extra):
#         title = win32gui.GetWindowText(hwnd)
#         if SCADA_WINDOW_TITLE.lower() in title.lower() and win32gui.IsWindowVisible(hwnd):
#             hwnd_result["hwnd"] = hwnd

#     win32gui.EnumWindows(_callback, None)
#     hwnd = hwnd_result["hwnd"]
#     if hwnd is None:
#         raise RuntimeError(f"'{SCADA_WINDOW_TITLE}' oynasi topilmadi.")

#     left, top, right, bottom = win32gui.GetWindowRect(hwnd)
#     width, height = right - left, bottom - top
#     hwnd_dc = win32gui.GetWindowDC(hwnd)
#     mfc_dc = win32ui.CreateDCFromHandle(hwnd_dc)
#     save_dc = mfc_dc.CreateCompatibleDC()
#     save_bitmap = win32ui.CreateBitmap()
#     save_bitmap.CreateCompatibleBitmap(mfc_dc, width, height)
#     save_dc.SelectObject(save_bitmap)
#     windll.user32.PrintWindow(hwnd, save_dc.GetSafeHdc(), 2)
#     bmpinfo = save_bitmap.GetInfo()
#     bmpstr = save_bitmap.GetBitmapBits(True)
#     img = Image.frombuffer("RGB", (bmpinfo["bmWidth"], bmpinfo["bmHeight"]), bmpstr, "raw", "BGRX", 0, 1)
#     win32gui.DeleteObject(save_bitmap.GetHandle())
#     save_dc.DeleteDC()
#     mfc_dc.DeleteDC()
#     win32gui.ReleaseDC(hwnd, hwnd_dc)
#     img.save(path)
#     return path


# def take_screenshot_from_screen(path: str = "shot.png"):
#     import mss
#     with mss.mss() as sct:
#         sct.shot(mon=1, output=path)
#     return path


# def take_screenshot(path: str = "shot.png"):
#     if CAPTURE_MODE == "url":
#         return take_screenshot_from_url(path)
#     elif CAPTURE_MODE == "window":
#         return take_screenshot_from_window(path)
#     elif CAPTURE_MODE == "screen":
#         return take_screenshot_from_screen(path)
#     raise ValueError(f"Noma'lum CAPTURE_MODE: {CAPTURE_MODE}")


# def _compress_image_for_ai(image_path: str) -> str:
#     """Rasmni kichraytiradi + JPEG'ga siqadi -> tezlik uchun. Base64
#     (str) qaytaradi."""
#     with Image.open(image_path) as img:
#         img = img.convert("RGB")
#         if img.width > IMAGE_MAX_WIDTH:
#             ratio = IMAGE_MAX_WIDTH / img.width
#             img = img.resize((IMAGE_MAX_WIDTH, int(img.height * ratio)), Image.LANCZOS)
#         buffer = io.BytesIO()
#         img.save(buffer, format="JPEG", quality=IMAGE_JPEG_QUALITY, optimize=True)
#         return base64.b64encode(buffer.getvalue()).decode("utf-8")


# def read_dashboard_with_ai(image_path: str, model: str = VISION_MODEL) -> dict:
#     b64_image = _compress_image_for_ai(image_path)
#     last_error = None

#     for attempt in range(1, MAX_RETRIES + 1):
#         try:
#             response = requests.post(
#                 f"{OLLAMA_BASE_URL}/api/chat",
#                 headers={"ngrok-skip-browser-warning": "true", "Content-Type": "application/json"},
#                 json={
#                     "model": model,
#                     "messages": [{"role": "user", "content": PROMPT, "images": [b64_image]}],
#                     "stream": False,
#                     "format": "json",
#                     "options": {"temperature": 0},
#                 },
#                 timeout=OLLAMA_TIMEOUT_SECONDS,
#             )
#             response.raise_for_status()
#             raw = response.json()["message"]["content"]
#             return json.loads(raw)
#         except (requests.RequestException, KeyError, json.JSONDecodeError) as e:
#             last_error = e
#             if attempt < MAX_RETRIES:
#                 print(f"[OGOHLANTIRISH] {attempt}-urinish muvaffaqiyatsiz ({e}). "
#                       f"{RETRY_DELAY_SECONDS}s kutib, qayta urinaman ({attempt + 1}/{MAX_RETRIES})...")
#                 time.sleep(RETRY_DELAY_SECONDS)
#             else:
#                 print(f"[XATO] {MAX_RETRIES} marta urinildi, hammasi muvaffaqiyatsiz.")

#     raise last_error













"""
vision_toolkit.py — skrinshot olish va AI (vision LLM) orqali JSON
qilish funksiyalari. Mustaqil sikli yo'q — capture_pipeline.py buni
chaqiradi.
"""

import base64
import io
import json
import re
import time
from concurrent.futures import ThreadPoolExecutor

from PIL import Image

import llm_client
from config import (
    CAPTURE_MODE,
    SCADA_URL,
    SCADA_WINDOW_TITLE,
    KNOWN_SENSOR_LABELS,
    VISION_MODEL,
    VISION_MAX_TOKENS,
    IMAGE_MAX_WIDTH,
    IMAGE_JPEG_QUALITY,
    VISION_MODE,
    VISION_GRID,
    VISION_GRID_OVERLAP,
    VISION_REGIONS,
    VISION_REGION_JPEG_QUALITY,
    VISION_REGION_MAX_TOKENS,
)

BASE_PROMPT = """Bu — sanoat SCADA/HMI tizimining ekran suratidir (skrinshot).
Vazifang: rasmda ko'ringan BARCHA o'lchov qiymatlarini, barcha
uskuna/aktuator holatlarini va barcha alarm/ogohlantirish xabarlarini
quyidagi JSON formatida chiqarib ber:

{
  "readings": {"<ekranda ko'ringan nom>": <son yoki matn>, ...},
  "equipment_states": {"<uskuna nomi>": "<ON/OFF/OPEN/CLOSED va h.k.>", ...},
  "alarms": ["<ekranda ko'ringan har bir alarm matni>", ...],
  "low_confidence_fields": ["<aniq emas deb hisoblagan kalitlar>", ...],
  "screen_title": "<ekran sarlavhasi, agar ko'ringan bo'lsa>"
}

MUHIM QOIDALAR — HAQIQATGA TO'LIQ SODIQLIK:
- FAQAT rasmda HAQIQATDA ko'ringan narsalarni yoz. O'zingdan HECH
  QANDAY qiymat, holat yoki tafsilot O'YLAB TOPMA yoki QO'SHMA —
  hatto mantiqan "shunday bo'lishi kerak" deb tuyulsa ham.
- TO'LIQLIK MUHIM: ekranda ko'ringan BARCHA raqamli ko'rsatkichni,
  BARCHA uskuna/nasos/klapan holatini yoz — birortasini ham
  "keraksiz" deb o'tkazib yuborma. Ekranda nechta alohida
  ko'rsatkich/qiymat ko'rinsa, JSON'da ham shuncha bo'lishi kerak.
- Nomlarni ekranda yozilgan holicha qoldir, tarjima qilma
- Bo'lim rasmda umuman bo'lmasa, mos maydonni bo'sh qoldir
- Faqat JSON qaytar, boshqa hech qanday izoh yozma

=== RAQAMLI QIYMATLAR FORMATI (TEZLIK UCHUN) ===
"readings" ichidagi raqamli qiymatlarni FAQAT SOF SON sifatida yoz —
o'lchov birligi (gal, ft, gpm, %, va h.k.) YOZMA, vergul ham QO'SHMA.
Masalan: "8,800.0 gal" -> 8800.0 (EMAS: "8,800.0 gal"); "75%" -> 75.

=== ANALOG STRELKALI ASBOBLAR UCHUN QOIDA ===
Raqamli yozuv bo'lsa — shunga tayan. Faqat strelka bo'lsa — taxmin qil
va "low_confidence_fields"ga qo'sh.

=== 7-SEGMENT DISPLEYLAR UCHUN QOIDA ===
Noaniq raqam bo'lsa — eng ehtimolli variantni yoz va
"low_confidence_fields"ga qo'sh.

=== RANGLI INDIKATORLAR UCHUN QOIDA ===
Chiroq holatini "equipment_states"da aniq so'z bilan ifodala (ON/OFF/
RUNNING/STOPPED). Noaniq bo'lsa "UNKNOWN" deb yoz va
"low_confidence_fields"ga qo'sh — taxmin qilib to'g'ri/noto'g'ri
javob berishdan ko'ra, halol "noaniq" deyish YAXSHIROQ."""


def _build_prompt() -> str:
    if not KNOWN_SENSOR_LABELS:
        return BASE_PROMPT
    mapping_lines = "\n".join(
        f'- "{label}" ko\'rinsa -> kalit nomi sifatida "{key}" ishlat'
        for label, key in KNOWN_SENSOR_LABELS.items()
    )
    return BASE_PROMPT + "\n\n=== MA'LUM KALIT NOMLARI ===\n" + mapping_lines


PROMPT = _build_prompt()


def take_screenshot_from_url(path: str = "shot.png"):
    from playwright.sync_api import sync_playwright

    with sync_playwright() as p:
        browser = p.chromium.launch()
        page = browser.new_page(viewport={"width": 1920, "height": 1080}, device_scale_factor=2)
        page.goto(SCADA_URL, timeout=45000, wait_until="domcontentloaded")
        try:
            page.wait_for_load_state("networkidle", timeout=15000)
        except Exception:
            pass
        page.wait_for_timeout(9000)
        page.screenshot(path=path, full_page=True)
        browser.close()
    return path


def take_screenshot_from_window(path: str = "shot.png"):
    import win32gui
    import win32ui
    from ctypes import windll

    hwnd_result = {"hwnd": None}

    def _callback(hwnd, _extra):
        title = win32gui.GetWindowText(hwnd)
        if SCADA_WINDOW_TITLE.lower() in title.lower() and win32gui.IsWindowVisible(hwnd):
            hwnd_result["hwnd"] = hwnd

    win32gui.EnumWindows(_callback, None)
    hwnd = hwnd_result["hwnd"]
    if hwnd is None:
        raise RuntimeError(f"'{SCADA_WINDOW_TITLE}' oynasi topilmadi.")

    left, top, right, bottom = win32gui.GetWindowRect(hwnd)
    width, height = right - left, bottom - top
    hwnd_dc = win32gui.GetWindowDC(hwnd)
    mfc_dc = win32ui.CreateDCFromHandle(hwnd_dc)
    save_dc = mfc_dc.CreateCompatibleDC()
    save_bitmap = win32ui.CreateBitmap()
    save_bitmap.CreateCompatibleBitmap(mfc_dc, width, height)
    save_dc.SelectObject(save_bitmap)
    windll.user32.PrintWindow(hwnd, save_dc.GetSafeHdc(), 2)
    bmpinfo = save_bitmap.GetInfo()
    bmpstr = save_bitmap.GetBitmapBits(True)
    img = Image.frombuffer("RGB", (bmpinfo["bmWidth"], bmpinfo["bmHeight"]), bmpstr, "raw", "BGRX", 0, 1)
    win32gui.DeleteObject(save_bitmap.GetHandle())
    save_dc.DeleteDC()
    mfc_dc.DeleteDC()
    win32gui.ReleaseDC(hwnd, hwnd_dc)
    img.save(path)
    return path


def take_screenshot_from_screen(path: str = "shot.png"):
    import mss
    with mss.mss() as sct:
        sct.shot(mon=1, output=path)
    return path


def take_screenshot(path: str = "shot.png"):
    if CAPTURE_MODE == "url":
        return take_screenshot_from_url(path)
    elif CAPTURE_MODE == "window":
        return take_screenshot_from_window(path)
    elif CAPTURE_MODE == "screen":
        return take_screenshot_from_screen(path)
    raise ValueError(f"Noma'lum CAPTURE_MODE: {CAPTURE_MODE}")


def _compress_image_for_ai(image_path: str) -> str:
    """Rasmni kichraytiradi + JPEG'ga siqadi -> tezlik uchun. Base64
    (str) qaytaradi."""
    with Image.open(image_path) as img:
        img = img.convert("RGB")
        if img.width > IMAGE_MAX_WIDTH:
            ratio = IMAGE_MAX_WIDTH / img.width
            img = img.resize((IMAGE_MAX_WIDTH, int(img.height * ratio)), Image.LANCZOS)
        buffer = io.BytesIO()
        img.save(buffer, format="JPEG", quality=IMAGE_JPEG_QUALITY, optimize=True)
        return base64.b64encode(buffer.getvalue()).decode("utf-8")


# =====================================================================
# ============  BO'LAKLARGA BO'LIB, PARALLEL O'QISH  ==================
# =====================================================================
# Butun ekranni bitta so'rovda o'qish ikki jihatdan yomon:
#   1) rasm 960 px ga kichraytirilganda zich ekrandagi raqamlar buziladi;
#   2) model 60+ qiymatni bitta uzun javobda yozadi — vaqtning katta
#      qismi aynan yozishga ketadi (~23 belgi/s).
# Bo'laklarga bo'lish ikkalasini ham hal qiladi: kesim kichraytirilmaydi
# (raqam ~2 barobar ko'p pikselga ega) va har bir so'rov javobning
# uchdan birini yozadi. Uchalasi PARALLEL ketadi — server buni ko'taradi.
#
# JSON o'rniga satrli ("R|nom|son") format ishlatiladi: u ~30% kamroq
# belgi, demak shuncha tezroq. Natija baribir o'sha dict ko'rinishida
# qaytariladi — quvurning qolgan qismi o'zgarishsiz ishlayveradi.

COMPACT_PROMPT = """Bu sanoat SCADA ekranining {qism}. Unda ko'ringan HAR BIR
raqamli qiymatni va HAR BIR uskuna holatini chiqar.

=== TO'LIQLIK — ENG MUHIM TALAB ===
Rasmni yuqoridan pastga, chapdan o'ngga BLOK-BLOK ko'zdan kechir.
Har bir ramka/panel ichidagi HAMMA qatorni yoz. Bitta panelda 4 ta
qiymat bo'lsa, to'rttasini ham yoz — birortasini "keraksiz" deb
o'tkazib yuborma. Ekranda nechta alohida ko'rsatkich ko'rinsa,
javobda ham shuncha satr bo'lishi kerak. Ro'yxatni yarim yo'lda
to'xtatma.

=== HAQIQATGA SODIQLIK ===
Faqat rasmda HAQIQATDA ko'ringanini yoz. O'zingdan son o'ylab topma.
Aniq o'qiy olmasang, o'sha satrni umuman tashlab ket — taxmin qilma.

=== FORMAT ===
Har bir satr alohida. Boshqa hech qanday matn, izoh yoki sarlavha YOZMA:
R|<ekranda yozilgan nom>|<sof son>
E|<uskuna nomi>|<holat>
A|<alarm matni>

R — raqamli o'lchov. Birlik (gpm, ntu, ft, gal, psi) YOZMA, vergul
    ishlatma.
E — uskuna holati: On/Off/Filtering/Stopped/Running va h.k.
    Agar bir xil turdagi bir nechta uskuna (nasoslar, aralashtirgichlar)
    bir-biridan RANGI yoki ko'rinishi bilan FARQ qilsa, ular bir xil
    holatda EMAS. Hammasini bitta holat bilan yozma — farqni aks
    ettir. Qaysi ko'rinish qaysi holatni bildirishiga ishonching
    bo'lmasa, o'sha uskunani umuman yozma (taxmin qilgandan ko'ra
    tashlab ketgan yaxshi).
A — alarm. Alarm bo'lmasa, A satrini umuman yozma.

=== NOM QO'YISH ===
Nomni EKRANDA YOZILGANIDEK ko'chir — TARJIMA QILMA, qisqartirma,
o'zingdan so'z qo'shma. Ekranda "Backwash" bo'lsa "Backwash" deb yoz,
"sath" yoki "height" deb YOZMA.

Agar qiymatning O'Z YOZUVI bo'lsa — FAQAT o'sha yozuvni ol, birlikni
nomga QO'SHMA:
    "Air Pressure      0 psi"        -> R|Air Pressure|0
    "Chem Pump #1  1617.1 mL / min"  -> R|Chem Pump #1|1617.1
    "Finished Chlorine 1.84 mg/L"    -> R|Finished Chlorine|1.84

Agar qiymatning yonida hech qanday yozuv bo'lmasa (panel ichidagi
qator), panel sarlavhasini va qiymatning BIRLIGINI birlashtir:
    Filter #1 panelida "93.3 in"      -> R|Filter #1 in|93.3
    Filter #1 panelida "33.4 in LOH"  -> R|Filter #1 in LOH|33.4
    Filter #1 panelida "857 gpm"      -> R|Filter #1 gpm|857
    Filter #1 panelida "0.120 ntu"    -> R|Filter #1 ntu|0.120
Shu qoida USKUNALARGA ham tegishli. Agar uskunaning tagida yoki
yonida faqat RAQAM tursa, panel sarlavhasini oldiga qo'shib yoz —
yolg'iz raqam nom emas:
    "Raw Water Pumps" panelidagi 1,2,3 raqamli nasoslar
        -> E|Raw Water Pump 1|Off        ("E|1|Off" DEB YOZMA)
    "Flash Mixers" panelidagi 1,2 raqamli aralashtirgichlar
        -> E|Flash Mixer 2|On

Shu qoida tufayli bitta ekran ikki marta o'qilganda nomlar BIR XIL
chiqadi. Nomsiz qiymatni TASHLAB KETMA — yuqoridagi usul bilan nomla."""


def _encode_pil(img: Image.Image, quality: int) -> str:
    """PIL rasmni JPEG+base64 qiladi. Kesim KICHRAYTIRILMAYDI — aniqlik
    aynan shundan kelib chiqadi."""
    buffer = io.BytesIO()
    img.convert("RGB").save(buffer, format="JPEG", quality=quality, optimize=True)
    return base64.b64encode(buffer.getvalue()).decode("utf-8")


def _unwrap_text(raw) -> str:
    """llm_client json_mode=False da javobni {"text": ...} ichiga o'raydi."""
    if isinstance(raw, dict):
        return raw.get("text") or json.dumps(raw, ensure_ascii=False)
    return str(raw)


# "0 gpm", "0.0 KGal", "75" — bular NOM emas, QIYMAT. Model ba'zan
# ustunlarni chalkashtirib, qiymatni nom o'rniga qo'yadi.
_QIYMATSIMON = re.compile(r"^[\d.,\s]+[A-Za-z%°\"']{0,6}$")
# "1", "#3", "2." — bular uskuna nomi emas. Ekran panelida nasoslar
# tagida faqat raqam yozilgan bo'ladi; model goh to'g'ri nom bilan
# ("Raw Water Pump 1"), goh yalang raqam bilan qaytaradi. Yalang
# raqam operatorga ham, AI maslahatchiga ham hech narsa bermaydi.
_RAQAMLI_NOM = re.compile(r"^[\d\s#.\-]+$")


_BOSH_SON = re.compile(r"^-?[\d.,]+")


def _nom_qiymatning_ozimi(nom: str, qiymat: float) -> bool:
    """Nom raqamdan boshlanib, o'sha raqam QIYMATNING O'ZI bo'lsa,
    model ustunlarni chalkashtirgan: "R|19.6 in LOH|19.6".

    Bu tekshiruv birlik ro'yxatiga TAYANMAYDI, shuning uchun istalgan
    dashboardda ishlaydi. Haqiqiy nom zarar ko'rmaydi:
    "24\" Flow gpm" qiymati 1786 — 24 bilan teng emas, demak qoladi."""
    m = _BOSH_SON.match(nom)
    if not m:
        return False
    try:
        bosh = float(m.group(0).rstrip(".,").replace(",", ""))
    except ValueError:
        return False
    if abs(bosh - qiymat) < 1e-9:
        return True
    return qiymat != 0 and abs(bosh - qiymat) / abs(qiymat) < 1e-6


def _kesilgan_kalitlarni_tashla(d: dict) -> dict:
    """Bo'lak chegarasi yozuvni o'rtasidan kessa, ustma-ust tushgan
    chiziqda yarim nom ko'rinadi: "Basin #3" yonida "asin #3" paydo
    bo'ladi. Qiymati bir xil va nomi ikkinchisining ichiga so'z
    o'rtasidan kirib ketgan kalit — kesilgani, tashlanadi.

    So'z chegarasidagi qo'shimchaga TEGILMAYDI: "Filter #1 in" va
    "Filter #1 in LOH" — ikkalasi ham haqiqiy, chunki ular orasida
    bo'sh joy bor."""
    uzunidan = sorted(d, key=len, reverse=True)
    natija = {}
    for k in uzunidan:
        kesilgan = False
        for t in natija:
            if len(k) >= len(t) or d[k] != natija[t]:
                continue
            # chapdan kesilgan:  "asin #3" <- "Basin #3"
            if t.endswith(k) and t[len(t) - len(k) - 1] != " ":
                kesilgan = True
            # o'ngdan kesilgan:  "Basin #" <- "Basin #3"
            elif t.startswith(k) and t[len(k)] != " ":
                kesilgan = True
            if kesilgan:
                break
        if not kesilgan:
            natija[k] = d[k]
    return natija


def parse_compact(text: str) -> dict:
    """"R|nom|son" satrlarini dict ga aylantiradi. Format buzilgan satr
    jimgina tashlab yuboriladi — bitta xato satr butun o'qishni
    yo'qotmasligi uchun."""
    readings, equipment, alarms = {}, {}, []
    for line in text.replace("\\n", "\n").splitlines():
        line = line.strip().strip('"').strip()
        if line.startswith("R|"):
            parts = line.split("|")
            if len(parts) >= 3 and parts[1].strip():
                nom = parts[1].strip()
                if _QIYMATSIMON.match(nom):
                    continue
                cleaned = re.sub(r"[^\d.\-]", "", parts[2])
                try:
                    qiymat = float(cleaned)
                except ValueError:
                    continue
                if not _nom_qiymatning_ozimi(nom, qiymat):
                    readings[nom] = qiymat
        elif line.startswith("E|"):
            parts = line.split("|")
            if len(parts) >= 3 and parts[1].strip():
                nom, holat = parts[1].strip(), parts[2].strip()
                if _RAQAMLI_NOM.match(nom):
                    continue
                # Notanish dashboardlarda model ba'zan tugma yoki
                # yorliqning O'ZINI holat deb qaytaradi: "E|BMS|BMS",
                # "E|CLOSE|CLOSE". Bunday yozuv hech qanday ma'lumot
                # bermaydi — shovqin bo'lib interfeysni to'ldiradi.
                if holat and holat.strip().lower() != nom.strip().lower():
                    equipment[nom] = holat
        elif line.startswith("A|"):
            txt = line[2:].strip()
            if txt:
                alarms.append(txt)
    return {"readings": readings, "equipment_states": equipment, "alarms": alarms}


def _read_one_region(args):
    name, box, image_path = args
    with Image.open(image_path) as full:
        crop = full.crop(box)
        b64 = _encode_pil(crop, VISION_REGION_JPEG_QUALITY)
        size = crop.size
    started = time.monotonic()
    raw = llm_client.chat_completion(
        model=VISION_MODEL, prompt=COMPACT_PROMPT.format(qism=f"{name} qismi"),
        image_b64=b64, json_mode=False, max_tokens=VISION_REGION_MAX_TOKENS,
        label=f"VISION-{name}",
    )
    part = parse_compact(_unwrap_text(raw))
    return name, size, time.monotonic() - started, part


def _find_gap(profile, target: int, search: int) -> int:
    """`target` atrofidagi `search` piksel ichidan ENG BO'SH joyni topadi.

    `profile` — har bir ustun (yoki qator) bo'ylab "to'ldirilganlik"
    o'lchovi. Panel ichi to'la, panellar orasi bo'sh bo'ladi — shuning
    uchun eng past nuqta aynan panellar orasidagi oraliqqa to'g'ri keladi.
    """
    lo = max(1, target - search)
    hi = min(len(profile) - 1, target + search)
    if hi <= lo:
        return target
    window = profile[lo:hi]
    return lo + int(window.index(min(window)))


def _content_profiles(img):
    """Rasmning ustun va qator bo'yicha "to'ldirilganlik" profillarini
    qaytaradi. Qo'shni piksellar farqi olinadi: bir xil rangli fon 0 ga
    yaqin, matn va ramkalar yuqori qiymat beradi."""
    import numpy as np
    small = img.convert("L")
    a = np.asarray(small, dtype=np.int16)
    dx = np.abs(np.diff(a, axis=1))
    dy = np.abs(np.diff(a, axis=0))
    col = np.zeros(a.shape[1], dtype=np.float64)
    col[:dx.shape[1]] = dx.sum(axis=0)
    row = np.zeros(a.shape[0], dtype=np.float64)
    row[:dy.shape[0]] = dy.sum(axis=1)
    # silliqlash — bitta ingichka chiziq "bo'sh joy" deb tanlanmasligi uchun
    k = max(3, min(a.shape[1], a.shape[0]) // 100)
    ker = np.ones(k) / k
    col = np.convolve(col, ker, mode="same")
    row = np.convolve(row, ker, mode="same")
    return col.tolist(), row.tolist()


def build_smart_regions(image_path: str) -> list:
    """Ekranni MAZMUNGA QARAB bo'laklarga bo'ladi.

    Ko'r panjara panellarni o'rtasidan kesib o'tadi: qiymat o'z nomidan
    ajralib qoladi yoki ikki bo'lakda ikki xil nom bilan o'qiladi.
    O'lchangan farq (shot_8, bir xil server sharoitida):
        ko'r panjara   -> 133 s, 94.7% aniqlik, 93% barqarorlik
        qo'lda sozlash ->  84 s, 98.2% aniqlik, 100% barqarorlik
    Bu funksiya qo'lda sozlashning foydasini koordinatasiz beradi:
    kesim joyi rasmning o'zidan, panellar orasidagi bo'sh oraliqdan
    topiladi. Shuning uchun ISTALGAN SCADA/HMI ekranida ishlaydi.
    """
    cols, rows = VISION_GRID
    cols, rows = max(1, cols), max(1, rows)
    with Image.open(image_path) as img:
        width, height = img.size
        col_p, row_p = _content_profiles(img)

    # Kesim joylari: teng bo'linish nuqtasi atrofida eng bo'sh joy
    xs = [0]
    for c in range(1, cols):
        t = int(c * width / cols)
        xs.append(_find_gap(col_p, t, int(width / cols * 0.22)))
    xs.append(width)
    ys = [0]
    for r in range(1, rows):
        t = int(r * height / rows)
        ys.append(_find_gap(row_p, t, int(height / rows * 0.22)))
    ys.append(height)

    ow = int(width / cols * VISION_GRID_OVERLAP)
    oh = int(height / rows * VISION_GRID_OVERLAP)
    regions = []
    for r in range(rows):
        for c in range(cols):
            x1 = max(0, xs[c] - (ow if c else 0))
            y1 = max(0, ys[r] - (oh if r else 0))
            x2 = min(width, xs[c + 1] + (ow if c < cols - 1 else 0))
            y2 = min(height, ys[r + 1] + (oh if r < rows - 1 else 0))
            name = f"{r + 1}-qator {c + 1}-ustun" if rows > 1 else f"{c + 1}-ustun"
            regions.append((name, (x1, y1, x2, y2)))
    return regions


def build_grid_regions(width: int, height: int) -> list:
    """Ekranni AVTOMATIK panjara bo'yicha bo'laklarga bo'ladi.

    Koordinata yozish shart emas — shuning uchun bu usul ISTALGAN SCADA
    yoki HMI ekranida ishlaydi: boshqa zavod, boshqa dizayn, boshqa
    o'lcham bo'lsa ham. Qo'lda yozilgan VISION_REGIONS faqat bitta aniq
    ekranga mos keladi va boshqasiga o'tganda mutlaqo yaroqsiz bo'ladi.

    Bo'laklar biroz ustma-ust kesiladi: chegarada turgan panel ikkiga
    bo'linib, qiymati o'z nomidan ajralib qolmasligi uchun.
    """
    cols, rows = VISION_GRID
    cols = max(1, cols)
    rows = max(1, rows)
    ow = int(width / cols * VISION_GRID_OVERLAP)
    oh = int(height / rows * VISION_GRID_OVERLAP)
    regions = []
    for r in range(rows):
        for c in range(cols):
            x1 = max(0, int(c * width / cols) - (ow if c else 0))
            y1 = max(0, int(r * height / rows) - (oh if r else 0))
            x2 = min(width, int((c + 1) * width / cols) + (ow if c < cols - 1 else 0))
            y2 = min(height, int((r + 1) * height / rows) + (oh if r < rows - 1 else 0))
            name = f"{r + 1}-qator {c + 1}-ustun" if rows > 1 else f"{c + 1}-ustun"
            regions.append((name, (x1, y1, x2, y2)))
    return regions


def _resolve_regions(image_path: str) -> list:
    """Qaysi bo'laklar ishlatilishini hal qiladi: qo'lda yozilganlarmi
    yoki avtomatik panjarami."""
    if VISION_MODE == "regions" and VISION_REGIONS:
        return list(VISION_REGIONS)
    try:
        return build_smart_regions(image_path)
    except Exception as e:
        # Mazmunga qarab bo'lish biror sababga ko'ra ishlamasa (masalan
        # numpy yo'q), oddiy panjaraga qaytamiz — quvur to'xtamasin.
        print(f"   [VISION] Mazmunli bo'lish ishlamadi ({e}), oddiy panjara.")
        with Image.open(image_path) as img:
            w, h = img.size
        return build_grid_regions(w, h)


def _read_by_regions(image_path: str) -> dict:
    jobs = [(name, box, image_path) for name, box in _resolve_regions(image_path)]
    started = time.monotonic()
    with ThreadPoolExecutor(max_workers=len(jobs)) as pool:
        parts = list(pool.map(_read_one_region, jobs))
    merged = {"readings": {}, "equipment_states": {}, "alarms": [],
              "low_confidence_fields": [], "screen_title": ""}
    for name, size, took, part in parts:
        print(f"   [VISION-{name}] {size[0]}x{size[1]}  {took:.0f}s  "
              f"{len(part['readings'])} qiymat, {len(part['equipment_states'])} uskuna")
        merged["readings"].update(part["readings"])
        merged["equipment_states"].update(part["equipment_states"])
        merged["alarms"].extend(part["alarms"])
    oldin = len(merged["readings"]) + len(merged["equipment_states"])
    merged["readings"] = _kesilgan_kalitlarni_tashla(merged["readings"])
    merged["equipment_states"] = _kesilgan_kalitlarni_tashla(merged["equipment_states"])
    tashlandi = oldin - len(merged["readings"]) - len(merged["equipment_states"])
    print(f"   [VISION] Bo'laklar parallel o'qildi: {time.monotonic()-started:.0f}s jami, "
          f"{len(merged['readings'])} qiymat, {len(merged['equipment_states'])} uskuna"
          + (f", {tashlandi} ta kesilgan nom tashlandi" if tashlandi else ""))
    return merged


def read_dashboard_with_ai(image_path: str, model: str = VISION_MODEL) -> dict:
    """Skrinshotni AI vision modelga yuboradi, dict qaytaradi.

    VISION_MODE="grid"    — ekran AVTOMATIK panjara bo'yicha bo'linib,
       bo'laklar parallel o'qiladi. Koordinata yozish shart emas, shuning
       uchun ISTALGAN SCADA/HMI ekranida ishlaydi. Standart rejim.
    VISION_MODE="regions" — qo'lda yozilgan VISION_REGIONS koordinatalari
       (faqat bitta aniq ekran uchun).
    VISION_MODE="full"    — butun ekran bitta JSON so'rovda. Eng sekin va
       eng kam aniq; zaxira variant.

    Qaytadigan dict uchala holatda ham bir xil ko'rinishda — quvurning
    qolgan qismi farqni sezmaydi."""
    if VISION_MODE in ("grid", "regions"):
        return _read_by_regions(image_path)
    b64_image = _compress_image_for_ai(image_path)
    return llm_client.chat_completion(
        model=model, prompt=PROMPT, image_b64=b64_image, json_mode=True,
        max_tokens=VISION_MAX_TOKENS, label="VISION"
    )